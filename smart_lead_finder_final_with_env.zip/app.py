import streamlit as st
from search import search_and_score_leads

st.set_page_config(page_title="Smart Lead Discovery System", layout="centered")
st.title("🔍 Smart Lead Discovery System")

job_title = st.text_input("🎯 Job Title")
sector = st.text_input("🏢 Sector")
country = st.text_input("🌍 Country")
city = st.text_input("🏙️ City")
service = st.selectbox("🛠️ Desired Service", ["SMS", "WhatsApp", "Chatbot"])
keywords = st.text_input("📌 Keywords (optional)", "AI, Marketing, Digital Solutions")

if st.button("🔎 Search"):
    if job_title and sector and country and city:
        query = f"{job_title} {sector} {country} {city} {service} {keywords}"
        with st.spinner("Searching for potential leads..."):
            results = search_and_score_leads(query)
        if results:
            st.success(f"✅ Found {len(results)} leads")
            for r in results:
                st.markdown(f"### [{r['name']}]({r['url']})")
                st.write(r["description"])
                st.write(f"⭐ Lead Score: {r['score']}")
                st.markdown("---")
        else:
            st.warning("No results found. Try different inputs.")
    else:
        st.error("Please fill in all required fields.")