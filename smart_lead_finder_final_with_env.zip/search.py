import requests
import os

def search_and_score_leads(query, max_results=10):
    tavily_api_key = os.getenv("TAVILY_API_KEY")
    if not tavily_api_key:
        raise ValueError("TAVILY_API_KEY not found. Make sure it's set in .env")

    url = "https://api.tavily.com/search"
    headers = {"Authorization": f"Bearer {tavily_api_key}"}
    data = {
        "query": query,
        "search_depth": "advanced",
        "include_answer": False,
        "include_images": False,
        "include_raw_content": False,
        "max_results": max_results
    }

    response = requests.post(url, json=data, headers=headers)
    if response.status_code != 200:
        return []

    results = []
    for r in response.json().get("results", []):
        results.append({
            "name": r.get("title", "No Title"),
            "description": r.get("content", "No description"),
            "url": r.get("url", "#"),
            "score": 80
        })
    return results