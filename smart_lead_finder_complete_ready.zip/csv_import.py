
import pandas as pd
import mysql.connector
import os
from dotenv import load_dotenv

load_dotenv()

def get_db_connection():
    return mysql.connector.connect(
        host=os.getenv("DB_HOST"),
        user=os.getenv("DB_USER"),
        password=os.getenv("DB_PASSWORD"),
        database=os.getenv("DB_NAME"),
        port=os.getenv("DB_PORT")
    )

def import_csv_to_db(file_path):
    df = pd.read_csv(file_path)
    conn = get_db_connection()
    cursor = conn.cursor()

    insert_query = '''
        INSERT INTO leads (full_name, job_title, company_name, sector, country, city,
                           service_requested, keywords, email, phone, linkedin_profile,
                           lead_score, status)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
    '''

    for _, row in df.iterrows():
        cursor.execute(insert_query, (
            row.get("Full Name", ""), row.get("Job Title", ""), row.get("Company Name", ""),
            "", "", "", "", "", row.get("Email", ""), "", row.get("LinkedIn URL", ""),
            75, "Not Contacted"
        ))
    conn.commit()
    cursor.close()
    conn.close()
