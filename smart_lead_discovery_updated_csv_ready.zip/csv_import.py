import pandas as pd

def process_csv(csv_file):
    df = pd.read_csv(csv_file)
    leads = []

    for _, row in df.iterrows():
        lead = {
            "full_name": row.get("Full Name", ""),
            "job_title": row.get("Job Title", ""),
            "company_name": row.get("Company", ""),
            "sector": "",
            "country": "",
            "city": "",
            "service_requested": "",
            "keywords": "",
            "email": row.get("Email", ""),
            "phone": "",
            "linkedin_profile": row.get("LinkedIn URL", ""),
            "lead_score": 80,
            "status": "Not Contacted"
        }
        leads.append(lead)

    return leads