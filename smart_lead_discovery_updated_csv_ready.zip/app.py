import streamlit as st
from search import search_and_score_leads
from csv_import import process_csv
from crm import insert_lead_to_db

st.set_page_config(page_title="Smart Lead Discovery System", layout="wide")
st.title("🔍 Smart Lead Discovery System")

source = st.radio("Select Search Source:", ["Tavily API", "PhantomBuster CSV", "Web Scraping (Coming Soon)"])

if source == "Tavily API":
    query = st.text_input("Enter Search Query")
    if st.button("Search"):
        if query:
            results = search_and_score_leads(query)
            for lead in results:
                st.write(f"**{lead['name']}**")
                st.write(lead['description'])
                st.write(f"🔗 [Link]({lead['url']})")
                st.write(f"⭐ Lead Score: {lead['score']}")
                st.markdown("---")
        else:
            st.warning("Please enter a query.")

elif source == "PhantomBuster CSV":
    uploaded_file = st.file_uploader("Upload CSV exported from PhantomBuster", type=["csv"])
    if uploaded_file is not None:
        leads = process_csv(uploaded_file)
        for lead in leads:
            insert_lead_to_db(lead)
            st.write(f"✅ Imported: {lead['full_name']} | {lead['job_title']} | {lead['linkedin_profile']}")

else:
    st.info("Web Scraping module will be available soon.")